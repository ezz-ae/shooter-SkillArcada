
"use client";

import { AdminAIAgent } from "@/components/admin-ai-agent";

export default function AIAgentPage() {
    return (
        <div className="h-full">
             <AdminAIAgent />
        </div>
    )
}
